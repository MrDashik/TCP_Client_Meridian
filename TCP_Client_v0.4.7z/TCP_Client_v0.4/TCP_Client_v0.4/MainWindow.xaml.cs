﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TCP_Client_v0._4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public int port; // Получаем порт из текстового поля
        public string ip; // чтение IP из textBox
        //public int SendTimeout = 10;
        public string send_1; // чтение 1 строки
        public string send_2; // чтение 2 строки
        public string send_3; // чтение 3 строки
        public TcpClient client = null;

        

        public MainWindow()
        {
            InitializeComponent();

        }

        public string GetMessage(string message)
        {
            //client = new TcpClient();
            //client.Connect(ip, port);
            var NetworkStream = client.GetStream();
            NetworkStream.Write(Encoding.UTF8.GetBytes(message));
            NetworkStream.Flush();
            //byte[] buffer = new byte[256];
            //string data = null;
            var data = new byte[256];
            //stream.Read(data, 0, data.Length);
            NetworkStream.Read(data, 0, data.Length);
            //Text_Data.AppendText("Полученные данные: {0}", Encoding.UTF8.GetString(data));
            Text_Data.Text += "Полученные данные: " + Encoding.UTF8.GetString(data) + Environment.NewLine;
            Text_Data.AppendText("Response: " + message);
            return string.Empty;

        }

        private void Button_Connect(object sender, RoutedEventArgs e)
        {
            port = int.Parse(text_port.Text); // Получаем порт из текстового поля
            ip = text_ip.Text; // чтение IP из textBox
            Text_Data.AppendText("Connecting to  " + ip + "\n");

            try
            {
                client = new TcpClient();
                //client.SendTimeout = 10;
                client.ConnectAsync(ip, port).Wait(TimeSpan.FromSeconds(10));
                GetMessage("Connecting\n");

            }
            catch (Exception ex)
            {
                Text_Data.AppendText("TCP connection timeout \n");
                MessageBox.Show($"Ошибка возникла из-за {ex}");             
                //Debug.WriteLine(ex.Message);
            }

            //while (true)
            //{
            //    // Проверяем подключение каждые 5 секунд
            //    if (!client.Connected)
            //    {
            //        Text_Data.AppendText("Подключение к серверу потеряно.");
            //        break;
            //    }

            //    Thread.Sleep(5000);
            //}


        }

        private void Button_Ping(object sender, RoutedEventArgs e)
        {
            Text_Data.AppendText("Checking the connection\r\nThe check was successful\r");
        }

        private void Button_Send_1(object sender, RoutedEventArgs e) // отпрвка с 1 сроки
        {

            port = int.Parse(text_port.Text); // Получаем порт из текстового поля
            ip = text_ip.Text; // чтение IP из textBox
            send_1 = text_send_1.Text; // чтение send_1 из textBox

            try
            {
                GetMessage(send_1 + "\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка возникла из-за {ex}");
            }
        }

        private void Button_Send_2(object sender, RoutedEventArgs e) // отпрвка с 2 сроки
        {
            port = int.Parse(text_port.Text); // Получаем порт из текстового поля
            ip = text_ip.Text; // чтение IP из textBox
            send_2 = text_send_2.Text; // чтение send_1 из textBox

            try
            {
                GetMessage(send_2 + "\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка возникла из-за {ex}");
            }
        }

        private void Button_Send_3(object sender, RoutedEventArgs e) // отпрвка с 3 сроки
        {


            port = int.Parse(text_port.Text); // Получаем порт из текстового поля
            ip = text_ip.Text; // чтение IP из textBox
            send_3 = text_send_3.Text; // чтение send_1 из textBox

            try
            {
                GetMessage(send_3 + "\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка возникла из-за {ex}");
            }


        }

        private void Button_Disconnect(object sender, RoutedEventArgs e) // Disconnect
        {

            client.Close();

            try
            {
                Text_Data.AppendText("Disconnect to  " + ip + "\n");
                //GetMessage("Disconnect" + "\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка возникла из-за {ex}");
            }


        }

        private void Button_enter_host(object sender, RoutedEventArgs e) // режим хоста для камеры
        {


            port = int.Parse(text_port.Text); // Получаем порт из текстового поля
            ip = text_ip.Text; // чтение IP из textBox

            try
            {
                GetMessage("<ESC> [ C" + "\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка возникла из-за {ex}");
            }


        }

        private void Button_enter_prog(object sender, RoutedEventArgs e) // режим програмирования для камеры
        {


            port = int.Parse(text_port.Text); // Получаем порт из текстового поля
            ip = text_ip.Text; // чтение IP из textBox

            try
            {
                GetMessage("<ESC> [ B" + "\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка возникла из-за {ex}");
            }


        }

        private void Button_exit_host(object sender, RoutedEventArgs e) // выход из режим програмирования для камеры
        {


            port = int.Parse(text_port.Text); // Получаем порт из текстового поля
            ip = text_ip.Text; // чтение IP из textBox

            try
            {
                GetMessage("<ESC> [ A" + "\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка возникла из-за {ex}");
            }


        }

        private void GetConnected()
        {

            while (true)
            {
                // Проверяем подключение каждые 5 секунд
                if (!client.Connected)
                {
                    Text_Data.AppendText("Подключение к серверу потеряно.");
                    break;
                }

                Thread.Sleep(5000);
            }


        }

    }

}
