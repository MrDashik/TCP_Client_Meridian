﻿//using System;
//using System.Net.Sockets;
//using System.Text;
//using System.Windows;

//namespace TCP_Client_v0._4
//{

//    public static class Client
//    {

//        public MainWindow()
//        {
//            InitializeComponent();
//        }

//        private void Button_Ping(object sender, RoutedEventArgs e)
//        {
//            Text_Data.AppendText("Checking the connection\r\nThe check was successful\r");
//        }
//    }
//}




//// Создаем новый TCP-клиент
//System.Net.Sockets.TcpClient tcpClient = new
//System.Net.Sockets.TcpClient();
//int port = int.Parse(text_port.Text); // Получаем порт из текстового поля
//string ip = text_ip.Text; // чтение IP из textBox
//// Пытаемся подключиться к серверу
//try
//{
//    tcpClient.Connect(ip, port);
//}
//catch (Exception ex)
//{
//    Text_Data.AppendText("Ошибка подключения: " + ex.Message);
//    //Console.WriteLine("Ошибка подключения: " + ex.Message);
//    return;
//}
//string ip = text_ip.Text; // чтение IP из textBox
//try
//{
//    IPAddress.Parse(ip); // попытка парсинга IP
//    //Text_Data.AppendText("$\"IP: {ip} - Valid IP\"\r");
//    MessageBox.Show($"IP: {ip} - Valid IP"); // вывод валидного IP
//}
//catch (FormatException)
//{
//    MessageBox.Show($"IP: {ip} - Invalid IP"); // вывод невалидного IP
//}

//// Отправляем сообщение на сервер
//string message = "Hello from the client!";
//byte[] messageBytes = Encoding.UTF8.GetBytes(message);

//try
//{
//    NetworkStream networkStream = tcpClient.GetStream();
//    networkStream.Write(messageBytes, 0, messageBytes.Length);
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Ошибка отправки сообщения: " + ex.Message);
//    //Text_Data.AppendText("Checking the connection\r\nThe check was successful\r");
//}
